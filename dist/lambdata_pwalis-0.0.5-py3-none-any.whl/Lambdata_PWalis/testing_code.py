import pandas as pd
import numpy as np


df = df.read_csv('https://raw.githubusercontent.com/PWalis/Datasets/master/auto_clean%20(1).csv?token=ALRO5WNNW7SXAARFV2OOHS247AZSM')
df
